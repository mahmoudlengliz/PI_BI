<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='profile' timestamp='1636477586297'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/build-admin/GitSources/studio-se-master/build/talend.studio.tos.di.product/target/products/org.talend.studio.tos.di.product/win32/win32/x86_64'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/build-admin/GitSources/studio-se-master/build/talend.studio.tos.di.product/target/products/org.talend.studio.tos.di.product/win32/win32/x86_64'/>
  </properties>
</profile>
